package com.example.spacewallpaper

import android.app.WallpaperManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Shader
import android.os.Build
import android.content.ContentValues
import android.provider.MediaStore
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SpaceWallpaperApp() }
    }
}

private val Bg = Color(0xFF08080D)
private val Panel = Color(0xFF15151F)
private val Accent = Color(0xFF9B7BFF)

@Composable
fun SpaceWallpaperApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var brightness by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(1f) }
    var saturation by remember { mutableFloatStateOf(0f) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var rotation by remember { mutableFloatStateOf(0f) }
    var blur by remember { mutableFloatStateOf(0f) }
    var mono by remember { mutableStateOf(true) }
    var resolution by remember { mutableStateOf("2K") }
    var transition by remember { mutableStateOf("Плавный") }
    var speed by remember { mutableFloatStateOf(1f) }
    var showTransitionPreview by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Выбери изображение, чтобы начать") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                bitmap = withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                }
                status = if (bitmap != null) "Изображение загружено" else "Не удалось открыть изображение"
            }
        }
    }

    val processed = remember(bitmap, brightness, contrast, saturation, mono) {
        bitmap?.let { applyAdjustments(it, brightness, contrast, saturation, mono) }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
                Text("SPACE WALLPAPER", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                Text("STUDIO  •  Космическая мастерская", color = Accent, fontSize = 12.sp)
                Spacer(Modifier.height(16.dp))

                Box(Modifier.fillMaxWidth().height(390.dp).clip(RoundedCornerShape(22.dp)).background(Color(0xFF101019)).border(1.dp, Color(0xFF333344), RoundedCornerShape(22.dp)), contentAlignment = Alignment.Center) {
                    if (processed != null) {
                        Image(processed.asImageBitmap(), null, Modifier.fillMaxSize().graphicsLayer { scaleX = zoom; scaleY = zoom; rotationZ = rotation; if (Build.VERSION.SDK_INT >= 31 && blur > 0f) renderEffect = android.graphics.RenderEffect.createBlurEffect(blur, blur, Shader.TileMode.CLAMP).asComposeRenderEffect() }, contentScale = ContentScale.Crop)
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("✦", color = Accent, fontSize = 54.sp)
                            Text("ТВОЙ КОСМОС", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("Загрузи фото или космические обои", color = Color.LightGray, fontSize = 12.sp)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Button(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("Выбрать изображение") }

                Section("Изображение") {
                    SliderSetting("Приближение", zoom, 1f, 3f, "%.1fx".format(zoom)) { zoom = it }
                    SliderSetting("Поворот", rotation, -180f, 180f, "%.0f°".format(rotation)) { rotation = it }
                    SliderSetting("Яркость", brightness, -0.5f, 0.5f, "%.2f".format(brightness)) { brightness = it }
                    SliderSetting("Контраст", contrast, 0.5f, 2f, "%.1f".format(contrast)) { contrast = it }
                    SliderSetting("Насыщенность", saturation, 0f, 2f, "%.1f".format(saturation)) { saturation = it }
                    SliderSetting("Размытие предпросмотра", blur, 0f, 20f, "%.0f".format(blur)) { blur = it }
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("Чёрно-белый фильтр", color = Color.White, modifier = Modifier.weight(1f))
                        Switch(checked = mono, onCheckedChange = { mono = it })
                    }
                    Text("Размытие показывается в предпросмотре на Android 12 и новее; экспорт сохраняет цветокоррекцию.", color = Color.Gray, fontSize = 10.sp)
                }

                Section("Переход между экранами") {
                    Text("Выбери эффект для просмотра", color = Color.LightGray, fontSize = 12.sp)
                    listOf("Плавный", "Параллакс", "Мягкий зум", "Сдвиг", "3D-эффект").forEach { item ->
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { transition = item }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(item, color = Color.White, modifier = Modifier.weight(1f))
                            RadioButton(selected = transition == item, onClick = { transition = item })
                        }
                    }
                    SliderSetting("Скорость перехода", speed, 0.25f, 2f, "%.2fx".format(speed)) { speed = it }
                    OutlinedButton(onClick = { showTransitionPreview = true }, modifier = Modifier.fillMaxWidth()) { Text("Предпросмотр перехода") }
                    Text("Важно: это демонстрация эффекта внутри приложения. Системную анимацию разблокировки Android обычно контролирует сам телефон или лаунчер.", color = Color.Gray, fontSize = 10.sp)
                }

                Section("Экспорт и установка") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("1080p", "2K", "4K").forEach { r ->
                            FilterChip(selected = resolution == r, onClick = { resolution = r }, label = { Text(r) })
                        }
                    }
                    Button(onClick = {
                        if (processed == null) { Toast.makeText(context, "Сначала выбери изображение", Toast.LENGTH_SHORT).show(); return@Button }
                        busy = true
                        scope.launch {
                            val ok = withContext(Dispatchers.IO) { saveExport(context, processed, resolution) }
                            busy = false
                            status = if (ok) "Файл подготовлен: ${resolution}" else "Ошибка сохранения"
                            Toast.makeText(context, status, Toast.LENGTH_LONG).show()
                        }
                    }, modifier = Modifier.fillMaxWidth(), enabled = processed != null && !busy) { Text(if (busy) "Подготовка…" else "Сохранить изображение") }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { setWallpaper(context, processed, WallpaperManager.FLAG_SYSTEM) }, modifier = Modifier.weight(1f), enabled = processed != null) { Text("Главный экран") }
                        OutlinedButton(onClick = { setWallpaper(context, processed, WallpaperManager.FLAG_LOCK) }, modifier = Modifier.weight(1f), enabled = processed != null) { Text("Блокировка") }
                    }
                    OutlinedButton(onClick = { setWallpaper(context, processed, WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK) }, modifier = Modifier.fillMaxWidth(), enabled = processed != null) { Text("Установить на оба экрана") }
                }
                Text(status, color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 12.dp, bottom = 24.dp))
            }
        }
    }

    if (showTransitionPreview && processed != null) {
        Dialog(onDismissRequest = { showTransitionPreview = false }) {
            TransitionPreview(processed!!, transition, speed) { showTransitionPreview = false }
        }
    }
}

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 16.dp).clip(RoundedCornerShape(18.dp)).background(Panel).padding(14.dp), content = {
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        content()
    })
}

@Composable
fun SliderSetting(label: String, value: Float, min: Float, max: Float, shown: String, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row { Text(label, color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f)); Text(shown, color = Accent, fontSize = 12.sp) }
        Slider(value = value, onValueChange = onChange, valueRange = min..max)
    }
}

@Composable
fun TransitionPreview(bitmap: Bitmap, effect: String, speed: Float, close: () -> Unit) {
    var forward by remember { mutableStateOf(false) }
    val amount by animateFloatAsState(if (forward) 1f else 0f, label = "transition", animationSpec = androidx.compose.animation.core.tween((900 / speed).toInt().coerceIn(250, 3000)))
    LaunchedEffect(Unit) { while (true) { forward = !forward; kotlinx.coroutines.delay((1000 / speed).toLong().coerceIn(300, 3000)) } }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Panel).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Предпросмотр: $effect", color = Color.White, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Box(Modifier.fillMaxWidth().height(440.dp).clip(RoundedCornerShape(16.dp)).background(Color.Black), contentAlignment = Alignment.Center) {
            Image(bitmap.asImageBitmap(), null, Modifier.fillMaxSize().graphicsLayer {
                when (effect) {
                    "Мягкий зум" -> { val s = 1f + amount * 0.25f; scaleX = s; scaleY = s }
                    "Сдвиг" -> translationX = (amount - 0.5f) * 160f
                    "Параллакс" -> { translationY = (amount - 0.5f) * 70f; scaleX = 1.12f; scaleY = 1.12f }
                    "3D-эффект" -> { rotationY = (amount - 0.5f) * 24f; cameraDistance = 12f * density }
                    else -> alpha = 0.45f + amount * 0.55f
                }
            }, contentScale = ContentScale.Crop)
            Text(if (amount < 0.5f) "ЭКРАН БЛОКИРОВКИ" else "ГЛАВНЫЙ ЭКРАН", color = Color.White, modifier = Modifier.align(Alignment.BottomCenter).padding(12.dp), fontSize = 11.sp)
        }
        Spacer(Modifier.height(12.dp))
        Text("Скорость: ${"%.2f".format(speed)}x", color = Color.LightGray, fontSize = 12.sp)
        TextButton(onClick = close) { Text("Закрыть") }
    }
}

private fun applyAdjustments(src: Bitmap, brightness: Float, contrast: Float, saturation: Float, mono: Boolean): Bitmap {
    val output = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
    val sat = if (mono) 0f else saturation
    val cm = ColorMatrix().apply { setSaturation(sat) }
    val c = contrast
    val b = brightness * 255f + 128f * (1f - c)
    val adjust = ColorMatrix(floatArrayOf(c,0f,0f,0f,b, 0f,c,0f,0f,b, 0f,0f,c,0f,b, 0f,0f,0f,1f,0f))
    cm.postConcat(adjust)
    val canvas = android.graphics.Canvas(output)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { colorFilter = ColorMatrixColorFilter(cm) }
    canvas.drawBitmap(src, 0f, 0f, paint)
    return output
}

private fun saveExport(context: android.content.Context, source: Bitmap, resolution: String): Boolean {
    return try {
    val width = when (resolution) { "4K" -> 2160; "2K" -> 1440; else -> 1080 }
    val height = (source.height.toFloat() / source.width * width).toInt().coerceAtLeast(width)
    val scaled = Bitmap.createScaledBitmap(source, width, height, true)
    val filename = "SpaceWallpaper_${resolution}_${System.currentTimeMillis()}.jpg"
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, filename)
        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SpaceWallpaperStudio")
        put(MediaStore.Images.Media.IS_PENDING, 1)
    }
    val resolver = context.contentResolver
    val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
    resolver.openOutputStream(uri)?.use { scaled.compress(Bitmap.CompressFormat.JPEG, 96, it) } ?: return false
    values.clear()
    values.put(MediaStore.Images.Media.IS_PENDING, 0)
    resolver.update(uri, values, null, null)
    true
} catch (_: Exception) { false }
}

private fun setWallpaper(context: android.content.Context, bitmap: Bitmap?, flags: Int) {
    if (bitmap == null) return
    try {
        WallpaperManager.getInstance(context).setBitmap(bitmap, null, true, flags)
        Toast.makeText(context, "Обои установлены", Toast.LENGTH_LONG).show()
    } catch (e: Exception) {
        Toast.makeText(context, "Не удалось установить обои: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
    }
}
